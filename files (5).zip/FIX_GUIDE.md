# German Learning App - Fix Guide

## Critical Fixes Needed

### FIX #1: Initialize Missing Global Variables

**File:** `static/js/app.js`  
**Line:** Top of file (before any functions that use these)

**Problem:** Quiz and unlimited state variables are undefined, causing runtime errors.

**Current Code:**
```javascript
// Line 19
let adjExerciseState = null;

// No initialization for quizState or unlimitedState
function startAdjectiveExercise() {
    // ...
}
```

**Fixed Code:**
Add these lines at the very top of app.js after the adjective list:

```javascript
// Initialize global state objects
let quizState = {};           // Track quiz progress per section
let unlimitedState = {};      // Track unlimited exercise progress per section
let adjExerciseState = null;  // Current adjective exercise

// Initialize theme
(function initTheme() {
    const savedTheme = localStorage.getItem('theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const theme = savedTheme || (prefersDark ? 'dark' : 'light');
    document.documentElement.setAttribute('data-theme', theme);
    
    if (document.readyState !== 'loading') {
        updateThemeIcon(theme);
    } else {
        document.addEventListener('DOMContentLoaded', () => updateThemeIcon(theme));
    }
})();
```

**Why:** Without these initializations, any code calling `quizState[sectionId]` or `unlimitedState[sectionId]` will fail with "Cannot read property of undefined" errors.

---

### FIX #2: Fix XSS Vulnerability in Feedback Display

**File:** `static/js/app.js`  
**Lines:** 541, 563 (and similar innerHTML usages)

**Problem:** Using `innerHTML` with potentially unsanitized content creates XSS vulnerability.

**Current Code (Line 541):**
```javascript
feedback.innerHTML = '❌ Not quite. Expected: <strong>' + state.exercise.answer + '</strong>';
```

**Current Code (Line 563):**
```javascript
feedback.innerHTML = '💡 Answer: <strong>' + state.exercise.answer + '</strong>';
```

**Fixed Code - Option A (Using textContent):**
```javascript
// Line 541 - Safe approach using textContent
const feedback = document.getElementById('uFeedback-' + sectionId);
const msg = document.createElement('div');
msg.innerHTML = '❌ Not quite. Expected: <strong></strong>';
msg.querySelector('strong').textContent = state.exercise.answer;
feedback.replaceChildren(msg.firstChild);
feedback.className = 'exercise-feedback incorrect';
```

**Fixed Code - Option B (Simple text only):**
```javascript
// Line 541 - Simplest fix
const feedback = document.getElementById('uFeedback-' + sectionId);
feedback.textContent = '❌ Not quite. Expected: ' + state.exercise.answer;
feedback.className = 'exercise-feedback incorrect';
```

**Fixed Code - Option C (Escape HTML):**
```javascript
// Utility function - add near top of file
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

// Then use it:
feedback.innerHTML = '❌ Not quite. Expected: <strong>' + escapeHtml(state.exercise.answer) + '</strong>';
```

**Recommendation:** Use Option C (escapeHtml) to maintain formatting while being secure.

---

### FIX #3: Implement Robust localStorage with Fallback

**File:** `static/js/app.js`  
**Lines:** 102-127 (replace entire storage functions)

**Problem:** localStorage fails silently in private browsing mode, causing progress loss.

**Current Code:**
```javascript
function saveUnlimitedProgress(sectionId) {
    try {
        const state = unlimitedState[sectionId];
        if (!state) return;
        localStorage.setItem('unlimited_' + sectionId, JSON.stringify({
            correct: state.correct,
            wrong: state.wrong,
            total: state.total
        }));
    } catch (e) {
        showError('Could not save progress.');
    }
}
```

**Fixed Code - Add Storage Manager:**
```javascript
// Storage manager with localStorage fallback
const StorageManager = {
    _cache: {},
    _isLocalStorageAvailable: null,
    
    _checkStorage() {
        if (this._isLocalStorageAvailable !== null) return;
        try {
            const test = '__storage_test__';
            localStorage.setItem(test, test);
            localStorage.removeItem(test);
            this._isLocalStorageAvailable = true;
        } catch (e) {
            this._isLocalStorageAvailable = false;
            console.warn('localStorage unavailable - using in-memory storage');
        }
    },
    
    setItem(key, value) {
        this._checkStorage();
        try {
            if (this._isLocalStorageAvailable) {
                localStorage.setItem(key, value);
            }
        } catch (e) {
            console.warn('Could not save to localStorage:', e);
        }
        this._cache[key] = value;
    },
    
    getItem(key) {
        this._checkStorage();
        try {
            if (this._isLocalStorageAvailable) {
                const item = localStorage.getItem(key);
                if (item !== null) return item;
            }
        } catch (e) {
            console.warn('Could not read from localStorage:', e);
        }
        return this._cache[key] || null;
    }
};

// Updated save functions
function saveUnlimitedProgress(sectionId) {
    try {
        const state = unlimitedState[sectionId];
        if (!state) return;
        StorageManager.setItem('unlimited_' + sectionId, JSON.stringify({
            correct: state.correct,
            wrong: state.wrong,
            total: state.total
        }));
    } catch (e) {
        console.error('Could not save progress:', e);
        showError('Progress may not be saved.');
    }
}

function loadUnlimitedProgress(sectionId) {
    try {
        const raw = StorageManager.getItem('unlimited_' + sectionId);
        if (!raw) return { correct: 0, wrong: 0, total: 0 };
        const obj = JSON.parse(raw);
        return {
            correct: obj.correct || 0,
            wrong: obj.wrong || 0,
            total: obj.total || 0
        };
    } catch (e) {
        return { correct: 0, wrong: 0, total: 0 };
    }
}

function saveQuizProgress(sectionId) {
    try {
        const state = quizState[sectionId];
        if (!state) return;
        StorageManager.setItem('quiz_' + sectionId, JSON.stringify({
            index: state.index,
            correct: state.correct,
            total: state.total
        }));
    } catch (e) {
        console.error('Could not save quiz progress:', e);
        showError('Quiz progress may not be saved.');
    }
}

function loadQuizProgress(sectionId) {
    try {
        const raw = StorageManager.getItem('quiz_' + sectionId);
        if (!raw) return { index: 0, correct: 0, total: 0 };
        const obj = JSON.parse(raw);
        return {
            index: obj.index || 0,
            correct: obj.correct || 0,
            total: obj.total || 0
        };
    } catch (e) {
        return { index: 0, correct: 0, total: 0 };
    }
}
```

**Why:** This provides:
- Automatic fallback to in-memory storage in private mode
- Cleaner error handling
- Better user feedback
- Persistent data even if localStorage fails temporarily

---

### FIX #4: Improve Sentence Validation (app.py)

**File:** `app.py`  
**Lines:** 60-73

**Problem:** Incomplete text normalization allows incorrect matches.

**Current Code:**
```python
@app.route("/api/check-sentence", methods=["POST"])
def check_sentence():
    """API endpoint to check sentence answers."""
    payload = request.get_json(silent=True)
    if not payload:
        return jsonify({"error": "Invalid request"}), 400
    user_answer = str(payload.get("answer", ""))[:500].strip().lower()
    correct_answer = str(payload.get("correct", ""))[:500].strip().lower()
    # Allow minor punctuation differences
    user_clean = user_answer.rstrip(".!?").strip()
    correct_clean = correct_answer.rstrip(".!?").strip()
    is_correct = user_clean == correct_clean
    return jsonify({"correct": is_correct, "expected": correct_answer})
```

**Fixed Code:**
```python
import re
import unicodedata

def normalize_text(text):
    """
    Normalize German text for comparison.
    - Convert to lowercase
    - Remove accents
    - Normalize whitespace
    - Remove punctuation
    """
    if not isinstance(text, str):
        return ""
    
    # Convert to lowercase
    text = text.lower()
    
    # Normalize unicode (é → e, etc.)
    text = unicodedata.normalize('NFKD', text)
    text = text.encode('ASCII', 'ignore').decode('ASCII')
    
    # Remove punctuation
    text = re.sub(r'[.!?,;:"—–\-]', '', text)
    
    # Normalize whitespace (multiple spaces → single space)
    text = re.sub(r'\s+', ' ', text)
    
    # Strip leading/trailing whitespace
    return text.strip()

@app.route("/api/check-sentence", methods=["POST"])
def check_sentence():
    """API endpoint to check sentence answers."""
    payload = request.get_json(silent=True)
    if not payload:
        return jsonify({"error": "Invalid request"}), 400
    
    # Validate input
    user_answer = payload.get("answer")
    correct_answer = payload.get("correct")
    
    if not user_answer or not correct_answer:
        return jsonify({"error": "Missing answer or correct response"}), 400
    
    # Limit length to prevent abuse
    user_answer = str(user_answer)[:500]
    correct_answer = str(correct_answer)[:500]
    
    # Normalize both answers
    user_clean = normalize_text(user_answer)
    correct_clean = normalize_text(correct_answer)
    
    # Compare
    is_correct = user_clean == correct_clean
    
    return jsonify({
        "correct": is_correct,
        "expected": correct_answer,
        "user_normalized": user_clean,
        "correct_normalized": correct_clean
    })
```

**Why:** This provides:
- Better handling of German umlauts and accents
- Consistent whitespace normalization
- Clearer validation
- Debug info (normalized versions) for troubleshooting

---

### FIX #5: Add Constants for DOM IDs

**File:** `static/js/app.js`  
**Lines:** Add after global state initialization

**Problem:** Magic strings for IDs scattered throughout code make refactoring difficult.

**Fixed Code:**
```javascript
// ID constants - centralized for easy refactoring
const DOM_IDS = {
    // Quiz IDs
    quizInput: (id) => `quizInput-${id}`,
    quizWord: (id) => `quizWord-${id}`,
    quizFeedback: (id) => `quizFeedback-${id}`,
    quizScore: (id) => `quizScore-${id}`,
    
    // Unlimited exercise IDs
    unlimitedInput: (id) => `uInput-${id}`,
    unlimitedCard: (id) => `uCard-${id}`,
    unlimitedFeedback: (id) => `uFeedback-${id}`,
    unlimitedAnswer: (id) => `uAnswer-${id}`,
    unlimitedBank: (id) => `uBank-${id}`,
    unlimitedHint: (id) => `uHint-${id}`,
    unlimitedCorrect: (id) => `uCorrect-${id}`,
    unlimitedWrong: (id) => `uWrong-${id}`,
    unlimitedTotal: (id) => `uTotal-${id}`,
    unlimitedProgress: (id) => `uProgress-${id}`,
    unlimitedScoreText: (id) => `uScoreText-${id}`,
    
    // Grid IDs
    grid: (id) => `grid-${id}`,
    
    // Tab IDs
    tab: (id) => `tab-${id}`,
    
    // Global
    globalError: 'globalError',
    mobileMenu: 'mobileMenu',
    themeToggle: '.theme-toggle',
    adjectiveContainer: 'adjective-exercise-container',
    adjectiveInput: 'adj-ex-input',
    adjectiveFeedback: 'adj-ex-feedback',
    bubbleContainer: 'bubble-container'
};

// Usage example - replace scattered getElementById calls
// OLD: document.getElementById('quizInput-' + sectionId)
// NEW: document.getElementById(DOM_IDS.quizInput(sectionId))
```

Then update functions to use these constants:
```javascript
function checkQuiz(sectionId) {
    const input = document.getElementById(DOM_IDS.quizInput(sectionId));
    const word = document.getElementById(DOM_IDS.quizWord(sectionId));
    // ... rest of function
}
```

---

### FIX #6: Add Missing Function Implementations

**File:** `static/js/app.js`  
**Lines:** 216-510 (currently truncated)

**These functions appear to be missing implementations:**

```javascript
// Add these function implementations
function startQuiz(sectionId) {
    if (!quizState) quizState = {};
    if (!vocabData || !vocabData[0]) {
        showError('No vocabulary data available');
        return;
    }
    
    // Load saved progress
    const saved = loadQuizProgress(sectionId);
    
    quizState[sectionId] = {
        words: vocabData[0].words || [],
        index: saved.index || 0,
        correct: saved.correct || 0,
        total: saved.total || 0
    };
    
    displayQuizWord(sectionId);
}

function displayQuizWord(sectionId) {
    const state = quizState[sectionId];
    if (!state || state.index >= state.words.length) {
        // Quiz complete
        document.getElementById(DOM_IDS.quizWord(sectionId)).textContent = 'Quiz Complete!';
        document.getElementById(DOM_IDS.quizScore(sectionId)).textContent = 
            `Final Score: ${state.correct} / ${state.total}`;
        return;
    }
    
    const word = state.words[state.index];
    document.getElementById(DOM_IDS.quizWord(sectionId)).textContent = word.de;
    document.getElementById(DOM_IDS.quizInput(sectionId)).value = '';
    document.getElementById(DOM_IDS.quizFeedback(sectionId)).textContent = '';
    document.getElementById(DOM_IDS.quizScore(sectionId)).textContent = 
        `Score: ${state.correct} / ${state.total}`;
}

function checkQuiz(sectionId) {
    const state = quizState[sectionId];
    if (!state || state.index >= state.words.length) return;
    
    const input = document.getElementById(DOM_IDS.quizInput(sectionId));
    const userAnswer = input.value.trim().toLowerCase();
    const correctAnswer = state.words[state.index].en.toLowerCase();
    
    const feedback = document.getElementById(DOM_IDS.quizFeedback(sectionId));
    
    if (userAnswer === correctAnswer) {
        state.correct++;
        feedback.textContent = '✅ Correct!';
        feedback.style.color = '#4CAF50';
    } else {
        feedback.innerHTML = '❌ Correct answer: <strong>' + escapeHtml(correctAnswer) + '</strong>';
        feedback.style.color = '#f44336';
    }
    
    state.total++;
    state.index++;
    
    saveQuizProgress(sectionId);
    
    setTimeout(() => displayQuizWord(sectionId), 1500);
}

function nextQuiz(sectionId) {
    const state = quizState[sectionId];
    if (!state) return;
    state.index++;
    saveQuizProgress(sectionId);
    displayQuizWord(sectionId);
}

function startUnlimitedExercise(sectionId) {
    if (!unlimitedState) unlimitedState = {};
    
    const saved = loadUnlimitedProgress(sectionId);
    
    unlimitedState[sectionId] = {
        correct: saved.correct,
        wrong: saved.wrong,
        total: saved.total,
        answered: false,
        exercise: generateRandomExercise(sectionId)
    };
    
    displayUnlimitedExercise(sectionId);
}

function generateRandomExercise(sectionId) {
    // Get exercises from page data
    const exercises = window.sentenceExercises || [];
    if (exercises.length === 0) {
        return { answer: 'No exercises available' };
    }
    return exercises[Math.floor(Math.random() * exercises.length)];
}

function displayUnlimitedExercise(sectionId) {
    const state = unlimitedState[sectionId];
    if (!state) return;
    
    const card = document.getElementById(DOM_IDS.unlimitedCard(sectionId));
    card.classList.remove('correct', 'incorrect');
    
    // Update exercise display (specific to your template)
    // This depends on how exercises are displayed
    
    state.answered = false;
}

function checkUnlimitedAnswer(sectionId) {
    // Implementation provided in earlier analysis
    // Already exists in the code - verify it's not truncated
}
```

**Why:** These function implementations are referenced in templates but may be truncated in the file.

---

## Testing the Fixes

After applying these fixes, test:

1. **Quiz functionality:**
   - Start a quiz
   - Answer questions
   - Close page and reopen (check progress persists)
   - Test in private browsing mode

2. **Unlimited exercises:**
   - Start an exercise
   - Submit answers
   - Check progress updates
   - Verify localStorage fallback works

3. **Security:**
   - Enter special characters in answers
   - Verify no XSS attacks work

4. **Adjective exercises:**
   - Start exercise
   - Complete answers
   - Verify stats track (after implementing Fix #8)

---

## Implementation Order

1. **First:** Apply Fix #1 (global initialization) - this is blocking
2. **Second:** Apply Fix #2 (XSS) - security critical
3. **Third:** Apply Fix #3 (storage) - affects user experience
4. **Fourth:** Apply Fix #5 (constants) - improves maintainability
5. **Fifth:** Apply Fix #4 (validation) - improves robustness
6. **Sixth:** Apply Fix #6 (missing functions) - ensures features work

