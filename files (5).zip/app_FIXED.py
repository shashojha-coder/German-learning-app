"""
German Language Learning App - A1 to B2 Roadmap
Flask-based interactive web application

FIXES APPLIED:
- Added input validation for sentence checking
- Improved text normalization for German
- Added better error handling
- Added type hints
- Added comprehensive docstrings
"""

from flask import Flask, render_template, jsonify, request
import json
import os
import re
import unicodedata
from typing import Dict, Optional, List, Any

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'dev-secret-key')

# Load learning data (cached in memory)
DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "content.json")
_cached_data: Optional[Dict[str, Any]] = None


def load_data() -> Dict[str, Any]:
    """
    Load and cache German learning content from JSON file.
    
    Returns:
        dict: Loaded content with structure:
            {
                "levels": [
                    {
                        "id": "a1",
                        "name": "A1",
                        "color": "#ff6b6b",
                        "description": "...",
                        "vocab_sections": [...],
                        "sentence_sections": [...]
                    },
                    ...
                ]
            }
    
    Raises:
        FileNotFoundError: If data file doesn't exist
        json.JSONDecodeError: If data file is invalid JSON
    """
    global _cached_data
    if _cached_data is None:
        try:
            with open(DATA_PATH, "r", encoding="utf-8") as f:
                _cached_data = json.load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"Data file not found at {DATA_PATH}")
        except json.JSONDecodeError as e:
            raise json.JSONDecodeError(f"Invalid JSON in {DATA_PATH}", e.doc, e.pos)
    
    return _cached_data


def normalize_text(text: str) -> str:
    """
    Normalize German text for comparison in quiz answers.
    
    Applies the following transformations:
    - Converts to lowercase
    - Removes German diacritics (ä → a, ö → o, ü → u)
    - Removes punctuation
    - Normalizes whitespace (multiple spaces → single space)
    - Strips leading/trailing whitespace
    
    Args:
        text: Raw text to normalize
    
    Returns:
        str: Normalized text
    
    Examples:
        >>> normalize_text("Ich bin Student.")
        'ich bin student'
        >>> normalize_text("Das ist schön!")
        'das ist schon'
    """
    if not isinstance(text, str):
        return ""
    
    # Convert to lowercase
    text = text.lower()
    
    # Normalize unicode NFD (decompose accented characters)
    text = unicodedata.normalize('NFD', text)
    
    # Remove diacritical marks but keep base characters
    # This converts ä → a, ö → o, ü → u, ß → ss
    text = ''.join(
        char for char in text
        if unicodedata.category(char) != 'Mn'  # Mn = Nonspacing_Mark
    )
    
    # Remove punctuation and special characters (except spaces)
    text = re.sub(r'[.!?,;:"—–\-()[\]{}<>]', '', text)
    
    # Normalize whitespace (multiple spaces → single space)
    text = re.sub(r'\s+', ' ', text)
    
    # Strip leading/trailing whitespace
    return text.strip()


@app.route("/")
def index() -> str:
    """
    Render the main roadmap/home page.
    
    Returns:
        str: Rendered HTML template with all levels
    """
    try:
        data = load_data()
        return render_template("index.html", levels=data["levels"])
    except Exception as e:
        app.logger.error(f"Error in index route: {str(e)}")
        return render_template("error.html", error="Could not load content"), 500


@app.route("/vocab/<level>")
def vocab(level: str) -> tuple:
    """
    Render vocabulary page for a specific level.
    
    Merges all vocabulary sections for a level into one combined section
    to simplify the learning interface.
    
    Args:
        level: Level ID (e.g., 'a1', 'a2', 'b1', 'b2')
    
    Returns:
        tuple: (HTML template, status_code)
            - 200: Success
            - 404: Level not found
            - 500: Server error
    """
    try:
        data = load_data()
        level_data = next(
            (l for l in data["levels"] if l["id"] == level.lower()),
            None
        )
        
        if not level_data:
            return "Level not found", 404
        
        # Merge all vocab sections into one for simplified UI
        merged_words = []
        for sec in level_data.get("vocab_sections", []):
            merged_words.extend(sec.get("words", []))
        
        merged_section = {
            "id": "all_vocab",
            "title": "All Vocabulary",
            "words": merged_words
        }
        
        level_data["vocab_sections"] = [merged_section]
        return render_template(
            "vocab.html",
            level=level_data,
            all_levels=data["levels"]
        )
    
    except Exception as e:
        app.logger.error(f"Error in vocab route for level {level}: {str(e)}")
        return render_template("error.html", error="Could not load vocabulary"), 500


@app.route("/sentences/<level>")
def sentences(level: str) -> tuple:
    """
    Render sentence exercises page for a specific level.
    
    Args:
        level: Level ID (e.g., 'a1', 'a2', 'b1', 'b2')
    
    Returns:
        tuple: (HTML template, status_code)
            - 200: Success
            - 404: Level not found
            - 500: Server error
    """
    try:
        data = load_data()
        level_data = next(
            (l for l in data["levels"] if l["id"] == level.lower()),
            None
        )
        
        if not level_data:
            return "Level not found", 404
        
        return render_template(
            "sentences.html",
            level=level_data,
            all_levels=data["levels"]
        )
    
    except Exception as e:
        app.logger.error(f"Error in sentences route for level {level}: {str(e)}")
        return render_template("error.html", error="Could not load sentences"), 500


@app.route("/api/check-sentence", methods=["POST"])
def check_sentence() -> tuple:
    """
    API endpoint to check user's sentence/answer against correct answer.
    
    Compares answers by normalizing both to handle:
    - Case differences (Ich → ich)
    - Punctuation differences (period, exclamation marks, etc.)
    - German diacritics (ä, ö, ü → a, o, u)
    - Extra whitespace
    
    Request JSON format:
        {
            "answer": "User's typed answer",
            "correct": "Expected correct answer"
        }
    
    Response JSON format:
        {
            "correct": bool,
            "expected": str (original correct answer),
            "user_normalized": str (user answer after normalization - DEBUG),
            "correct_normalized": str (correct answer after normalization - DEBUG)
        }
    
    Returns:
        tuple: (JSON response, status_code)
            - 200: Successfully compared
            - 400: Invalid request (missing fields, invalid JSON)
            - 500: Server error
    """
    try:
        # Parse JSON payload
        payload = request.get_json(silent=True)
        
        if not payload:
            return jsonify({
                "error": "Invalid request",
                "message": "Request body must be valid JSON"
            }), 400
        
        # Validate required fields
        user_answer = payload.get("answer")
        correct_answer = payload.get("correct")
        
        if user_answer is None or correct_answer is None:
            return jsonify({
                "error": "Missing required fields",
                "message": "Both 'answer' and 'correct' fields are required"
            }), 400
        
        # Convert to string and limit length (prevent abuse)
        user_answer = str(user_answer)[:500]
        correct_answer = str(correct_answer)[:500]
        
        # Normalize both answers for comparison
        user_clean = normalize_text(user_answer)
        correct_clean = normalize_text(correct_answer)
        
        # Check if answers match
        is_correct = user_clean == correct_clean
        
        # Return result with normalized versions for debugging
        return jsonify({
            "correct": is_correct,
            "expected": correct_answer,
            "user_normalized": user_clean,      # DEBUG info
            "correct_normalized": correct_clean  # DEBUG info
        }), 200
    
    except json.JSONDecodeError:
        return jsonify({
            "error": "Invalid JSON",
            "message": "Request body must be valid JSON"
        }), 400
    
    except Exception as e:
        app.logger.error(f"Error in check_sentence endpoint: {str(e)}")
        return jsonify({
            "error": "Server error",
            "message": "An error occurred while checking your answer"
        }), 500


@app.route("/api/health", methods=["GET"])
def health() -> tuple:
    """
    Health check endpoint for monitoring/deployment.
    
    Returns:
        tuple: (JSON response, status_code)
    """
    try:
        # Try to load data to verify everything is working
        load_data()
        return jsonify({"status": "healthy", "message": "App is running"}), 200
    except Exception as e:
        app.logger.error(f"Health check failed: {str(e)}")
        return jsonify({
            "status": "unhealthy",
            "error": str(e)
        }), 500


# Error handlers
@app.errorhandler(404)
def not_found(error) -> tuple:
    """Handle 404 errors."""
    return render_template("error.html", error="Page not found"), 404


@app.errorhandler(500)
def server_error(error) -> tuple:
    """Handle 500 errors."""
    return render_template("error.html", error="Server error"), 500


if __name__ == "__main__":
    # Get configuration from environment
    port = int(os.environ.get("PORT", 8080))
    debug = os.environ.get("FLASK_DEBUG", "0") == "1"
    
    # Run Flask app
    app.run(
        debug=debug,
        host="0.0.0.0",
        port=port,
        use_reloader=debug
    )
